# Railway Terminus MARL — Platform Allocation

A working scaffold for allocating trains to platforms at a rail **terminus**
(a terminal/end station with several platforms, e.g. Chennai Central,
Howrah) using multi-agent reinforcement learning.

## How the problem is modeled

- **Agents = platforms** (fixed set, e.g. 6). This is the key design choice:
  the number of platforms at a terminus doesn't change mid-episode, so it
  drops cleanly into PettingZoo's `ParallelEnv` + SuperSuit + Stable-
  Baselines3 with **parameter sharing** (one policy, reused by every
  platform).
- **Trains** arrive on a schedule into a shared waiting queue (visible to
  every platform agent, padded to `max_queue`).
- Each timestep, every **free** platform picks: "accept queue slot *i*" or
  "wait". The environment resolves conflicts (two platforms picking the
  same train — lowest platform id wins), checks compatibility (platform
  length class ≥ train length class, electrification if required), and
  computes reward from match quality, wait-time penalty, and a small
  shared team term for overall queue length.
- This mirrors the real allocation problem: express vs local priority,
  platform length/electrification constraints, turnaround buffers between
  trains, and the goal of minimizing average dwell/wait while keeping
  every platform utilized.

## Scenarios

- `default_scenario()` — a small 6-platform toy scenario, useful for fast
  iteration.
- `mgr_chennai_central_scenario()` — approximates **MGR Chennai Central
  (MAS)**'s real platform structure: 17 platforms total — 12 in the main
  building (including the short bay platform **"2A"**, used in real life
  for premium short-rake trains like the Rajdhani/Shatabdi services) plus
  5 at the **Moore Market Complex** for suburban EMU services, all
  electrified. Traffic mix: ~16 long-distance express/premium trains and
  ~46 suburban EMU services over a ~366-step horizon. Train names/numbers
  and exact schedules are illustrative flavor, not a live timetable — the
  *platform structure* (12 main + 5 suburban + the 2A bay) is the real,
  sourced part.

## Project layout

```
railway_terminal_marl/
  env/
    config.py          # Platform + train scenario definitions (default + MGR Chennai Central)
    terminal_env.py     # PettingZoo ParallelEnv: RailwayTerminusEnv
  training/
    train.py            # SuperSuit + SB3 PPO training, parameter-shared, --scenario flag
    callbacks.py         # Logs per-episode metrics to logs/metrics.jsonl
  viz/
    mgr_station_simulator_template.html   # Station-schematic live simulation (the UI)
    dashboard_template.html                # Training curves (avg wait, invalid actions, conflicts)
    build.py                               # Inlines logs/*.json(l) into the HTML files above
  logs/
    ppo_terminus.zip     # Trained model (MGR Chennai Central scenario)
    metrics.jsonl        # Per-episode training metrics
    events.json          # One clean rollout: allocation + conflict events
```

## Running it

```bash
pip install pettingzoo supersuit stable-baselines3 gymnasium

# train on the MGR Chennai Central scenario (also runs one deterministic
# rollout at the end and writes events.json)
python3 -m training.train --timesteps 300000 --scenario mgr_chennai_central

# regenerate the two HTML UIs from the latest logs
python3 viz/build.py
```

Open `viz/mgr_station_simulator.html` for the live station simulation —
two terminal sections (main + suburban), each platform shown as a bay with
occupancy, dwell-time progress, a signal light, and a departure-board
style ticker of the latest allocation. `viz/dashboard.html` is the
separate training-metrics view (avg wait, invalid actions, conflicts per
episode). Both are self-contained files (data is inlined).

## What actually trained

**MGR Chennai Central scenario** (17 platforms, 62 trains, horizon 366),
300k timesteps of PPO:

- Average wait per train: **~1.0 → ~0.4** timesteps, all 62 trains served
- Invalid (incompatible-platform) actions: **→ 0** in the final rollout
- Platform-claim conflicts stayed nontrivial (~560 in the final rollout) —
  since platforms act independently with no direct communication, several
  often "race" for the same desirable train. This doesn't hurt throughput
  here (queue is large enough to absorb it) but is the main thing worth
  improving next — see below.

**Small toy scenario** (6 platforms, 24 trains, horizon 220), 200k
timesteps: average wait **~4.5 → ~0.2**, invalid actions **~940 → 0**.

## Extending this

- **Reduce platform-claim conflicts**: platforms currently act independently
  (parameter sharing, no communication). A centralized critic (MAPPO) or an
  explicit "claim broadcast" in the observation (what did other platforms
  just bid on) would likely cut conflicts a lot on the 17-platform scenario.
- **Bigger/networked scenarios**: swap in a generator with more platforms,
  delayed/disrupted arrivals, or maintenance windows. The env doesn't
  hardcode platform count.
- **Live simulation/dashboard**: both HTML files currently read a static
  snapshot from `logs/`. For a live view during training, have the
  callback push rows over a WebSocket, or poll the files.
- **Realistic constraints**: add track conflicts (shared approach lines
  before the platforms), crew/rolling-stock turnaround rules, or real MAS
  timetable data in place of the illustrative train schedule.

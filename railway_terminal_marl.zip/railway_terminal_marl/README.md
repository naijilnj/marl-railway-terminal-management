# Railway Terminus MARL — Platform Allocation

A working scaffold for allocating trains to platforms at a rail **terminus**
(a terminal/end station with several platforms, e.g. Chennai Central,
Howrah) using multi-agent reinforcement learning.

## How the problem is modeled

- **Agents = platforms** (fixed set, e.g. 6). This is the key design choice:
  the number of platforms at a terminus doesn't change mid-episode, so it
  drops cleanly into PettingZoo's `ParallelEnv` + SuperSuit + Stable-
  Baselines3 with **parameter sharing** (one policy, reused by every
  platform).
- **Trains** arrive on a schedule into a shared waiting queue (visible to
  every platform agent, padded to `max_queue`).
- Each timestep, every **free** platform picks: "accept queue slot *i*" or
  "wait". The environment resolves conflicts (two platforms picking the
  same train — lowest platform id wins), checks compatibility (platform
  length class ≥ train length class, electrification if required), and
  computes reward from match quality, wait-time penalty, and a small
  shared team term for overall queue length.
- This mirrors the real allocation problem: express vs local priority,
  platform length/electrification constraints, turnaround buffers between
  trains, and the goal of minimizing average dwell/wait while keeping
  every platform utilized.

## Project layout

```
railway_terminal_marl/
  env/
    config.py          # Platform + train scenario definitions
    terminal_env.py     # PettingZoo ParallelEnv: RailwayTerminusEnv
  training/
    train.py            # SuperSuit + SB3 PPO training, parameter-shared
    callbacks.py         # Logs per-episode metrics to logs/metrics.jsonl
  viz/
    simulator_template.html   # Gantt-timeline replay of one rollout
    dashboard_template.html   # Training curves (avg wait, invalid actions, conflicts)
    build.py                  # Inlines logs/*.json(l) into the two HTML files above
  logs/
    ppo_terminus.zip     # Trained model
    metrics.jsonl        # Per-episode training metrics
    events.json          # One clean rollout (scenario + allocation events)
```

## Running it

```bash
pip install pettingzoo supersuit stable-baselines3 gymnasium

# train (also runs one deterministic rollout at the end and writes events.json)
python3 -m training.train --timesteps 200000

# regenerate the two HTML visualizers from the latest logs
python3 viz/build.py
```

Open `viz/simulator.html` to replay the trained policy's allocation
decisions over time, or `viz/dashboard.html` to see the training curves.
Both are self-contained files (data is inlined), so they can be opened
directly or hosted anywhere.

## What actually trained

With the included scenario (6 platforms, 24 trains, horizon 220 steps) and
200k timesteps of PPO:

- Average wait per train: **~4.5 → ~0.2** timesteps
- Invalid actions per episode: **~940 → 0**
- All 24 trains served every episode once training stabilized

## Extending this

- **Bigger/networked scenarios**: swap `default_scenario()` for a
  generator with more platforms, delayed/disrupted arrivals, or maintenance
  windows. The env doesn't hardcode platform count.
- **Richer coordination**: the current reward has one shared term; you can
  push further into cooperative MARL (e.g. QMIX-style value decomposition)
  if independent PPO plateaus on harder scenarios.
- **Live dashboard**: `dashboard.html` currently reads a static
  `metrics.jsonl` snapshot. For a live view during training, have the
  callback also push rows over a WebSocket, or poll the file.
- **Realistic constraints**: add track conflicts (shared approach lines
  before the platforms), crew/rolling-stock turnaround rules, or
  platform-specific dwell penalties for long trains on short platforms.

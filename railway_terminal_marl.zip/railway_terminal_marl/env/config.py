"""
Scenario configuration for the railway terminus MARL environment.

A "terminal" here is a single terminus station with several platforms.
Trains arrive according to a schedule and must be allocated to a
compatible platform. Agents = platforms (fixed set). Trains form a
shared waiting queue that every platform agent observes.
"""
from dataclasses import dataclass, field
from typing import List

LENGTH_CLASSES = ["short", "medium", "long"]  # ordinal: short < medium < long


@dataclass
class Platform:
    id: int
    length_class: str      # max train length this platform can accept
    electrified: bool      # whether platform has electrified line / OHE
    turnaround_buffer: int = 2  # min timesteps needed between departure and next arrival


@dataclass
class TrainSpec:
    id: int
    scheduled_arrival: int   # timestep the train enters the waiting queue
    dwell_time: int          # timesteps the train occupies the platform once allocated
    length_class: str        # required platform length class (platform must be >= this)
    electrified_required: bool
    priority: int             # 0 = express (higher priority), 1 = local


def length_ok(platform_class: str, train_class: str) -> bool:
    order = {c: i for i, c in enumerate(LENGTH_CLASSES)}
    return order[platform_class] >= order[train_class]


@dataclass
class ScenarioConfig:
    horizon: int = 200
    max_queue: int = 10          # max waiting trains visible in observation (padded)
    platforms: List[Platform] = field(default_factory=list)
    trains: List[TrainSpec] = field(default_factory=list)


def default_scenario(seed: int = 0) -> ScenarioConfig:
    """A modest, reproducible scenario: 6 platforms, ~24 trains over 200 steps."""
    import random
    rng = random.Random(seed)

    platforms = [
        Platform(id=0, length_class="long", electrified=True, turnaround_buffer=3),
        Platform(id=1, length_class="long", electrified=True, turnaround_buffer=3),
        Platform(id=2, length_class="medium", electrified=True, turnaround_buffer=2),
        Platform(id=3, length_class="medium", electrified=False, turnaround_buffer=2),
        Platform(id=4, length_class="short", electrified=False, turnaround_buffer=1),
        Platform(id=5, length_class="short", electrified=False, turnaround_buffer=1),
    ]

    trains = []
    t = 0
    for i in range(24):
        t += rng.randint(4, 10)
        length_class = rng.choices(LENGTH_CLASSES, weights=[0.3, 0.4, 0.3])[0]
        electrified_required = rng.random() < 0.4 and length_class != "short"
        priority = 0 if rng.random() < 0.25 else 1
        dwell = rng.randint(6, 14) if priority == 1 else rng.randint(4, 8)
        trains.append(TrainSpec(
            id=i,
            scheduled_arrival=t,
            dwell_time=dwell,
            length_class=length_class,
            electrified_required=electrified_required,
            priority=priority,
        ))

    return ScenarioConfig(horizon=220, max_queue=10, platforms=platforms, trains=trains)
